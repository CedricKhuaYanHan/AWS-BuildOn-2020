const express = require('express');
const AWS = require('aws-sdk');
const { v4 : uuid } = require('uuid');
const CORS = require('cors');

// EXPRESS init & settings
const app = express()
const port = process.env.PORT || 4000

// AWS config & init
AWS.config.update({
    region : 'us-east-1',
    endpoint : 'dynamodb.us-east-1.amazonaws.com'
})

const db = new AWS.DynamoDB()
const docClient = new AWS.DynamoDB.DocumentClient()

// The Alphabet
let abc = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

// CORS
app.use(CORS())

// GET HOMEPAGE
app.get('/', (req, res) => {
    res.send('Welcome to the noobmaster69 Backend API!')
})

// GET ALL VISITS
app.get('/visits', (req, res) => {
    docClient.scan({
        TableName: 'Visits'
    }, (err, data) => {
        if (err) console.error(err)
        else res.send(data)
    })
})

// POST NEW VISIT
app.post('/newVisit', express.json(), (req, res) => {
    let ID = uuid()
    docClient.put({
        TableName: "Visits",
        Item: Object.assign({}, req.body, {ID})
    }, (err, data) => {
        if (err) {
            console.error(err)
            res.send(err).status(400)
        } else {
            res.send(`Item created with ID: ${ID}`)
            console.log(`Item created with ID: ${ID}`)
        }
    })
})

// PUT (SINGLE) VISIT
app.put('/updateVisit/:id', express.json(), (req, res) => {
    console.log({
        TableName: "Visits",
        Key: {
            "ID": req.params.id
        },
        UpdateExpression: Object.keys(req.body).reduce((acc, cur, i) => {
            if (i) {
                return acc + `, ${cur} = :${abc[i]}`
            } else {
                return acc + `${cur} = :${abc[i]}`
            }
        }, "set "),
        ExpressionAttributeValues: Object.keys(req.body).reduce((acc, cur, i) => {
            return Object.assign({}, acc, {[`:${abc[i]}`]: req.body[cur]})
        }, {})
    })
    docClient.update({
        TableName: "Visits",
        Key: {
            "ID": req.params.id
        },
        UpdateExpression: Object.keys(req.body).reduce((acc, cur, i) => {
            if (i) {
                return acc + `, ${cur} = :${abc[i]}`
            } else {
                return acc + `${cur} = :${abc[i]}`
            }
        }, "set "),
        ExpressionAttributeValues: Object.keys(req.body).reduce((acc, cur, i) => {
            return Object.assign({}, acc, {[`:${abc[i]}`]: req.body[cur]})
        }, {})
    }, (err, data) => {
        if (err) {
            console.error(err)
            res.send(err).status(400)
        } else {
            res.send(`Item update with ID: ${req.params.id}`)
            console.log(data, `Item updated with ID: ${req.params.id}`)
        }
    })
})

// DELETE (SINGLE) VISIT
app.delete('/deleteVisit/:id', (req, res) => {
    docClient.delete({
        TableName: "Visits",
        Key: {
            "ID": req.params.id
        }
    }, (err, data) => {
        if (err) {
            console.error(err)
            res.send(err).status(400)
        } else {
            res.send(`Item deleted with ID: ${req.params.id}`)
            console.log(`Item deleted with ID: ${req.params.id}`)
        }
    })
})

// GET ALL RULES
app.get('/rules', (req, res) => {
    docClient.scan({
        TableName: 'Rules'
    }, (err, data) => {
        if (err) console.error(err)
        else res.send(data)
    })
})

// UPDATE RULE
app.post('/updateRules', express.json(), (req, res) => {
    docClient.batchWrite({
        RequestItems: {
            Rules: Object.keys(req.body).map(e => {
                return {
                    PutRequest: {
                        Item: {
                            Field: e,
                            Value: req.body[e]
                        }
                    }
                }
            })
        }
    }, (err, data) => {
        if (err) {
            console.error(err)
            res.send(err).status(400)
        } else {
            res.send(`Items updated!`)
            console.log(`Items updated!`)
        }
    })
})

app.listen(port, () => console.log(`Server ONLINE on PORT: ${port}`))