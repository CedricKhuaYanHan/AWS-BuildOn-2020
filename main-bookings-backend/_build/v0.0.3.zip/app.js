// IMPORTS (Main)
const express = require('express');
const CORS = require('cors');

// IMPORTS (Routes)
const visits = require('./routes/visits');
const rules = require('./routes/rules');
const patients = require('./routes/patients');

// EXPRESS init & settings
const app = express()
const port = process.env.PORT || 4000

// CORS
app.use(CORS())

// GET Root
app.get('/', (req, res) => {
    res.send('Welcome to the noobmaster69 Backend API!')
})

// USE Visits
app.use('/visits', visits)

// USE Rules
app.use('/rules', rules)

// USE Patients
app.use('/patients', patients)

// INIT Server
app.listen(port, () => console.log(`Server ONLINE on PORT: ${port}`))