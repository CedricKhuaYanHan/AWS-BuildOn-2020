const AWS = require('aws-sdk');

// AWS config & init
AWS.config.update({
    region : 'us-east-1',
    endpoint : 'dynamodb.us-east-1.amazonaws.com'
})

// DynamoDB
const db = new AWS.DynamoDB()
const docClient = new AWS.DynamoDB.DocumentClient()

// Exports
module.exports = {db, docClient}