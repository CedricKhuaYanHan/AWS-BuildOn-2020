// IMPORTS (Main)
const express = require('express');
const CORS = require('cors');

// IMPORTS (Routes)
const visits = require('./routes/visits');
const rules = require('./routes/rules');
const patients = require('./routes/patients');
const beds = require('./routes/beds');

// EXPRESS init & settings
const app = express()
const port = process.env.PORT || 4000

// CORS
app.use(CORS())

// GET Root
app.get('/', (req, res) => {
    res.send('Welcome to the noobmaster69 Backend API!')
})

// ROUTES
app.use('/visits', visits)
app.use('/rules', rules)
app.use('/patients', patients)
app.use('/beds', beds)

// INIT Server
app.listen(port, () => console.log(`Server ONLINE on PORT: ${port}`))